# loger
loger can easily control your log printing and sveing 