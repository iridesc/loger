# loger
loger 可以轻松控制你的log打印和输出
loger can easily control your log printing and sveing 
##  安装 install 

```
pip install loger
```
## 使用

下载并运行./test.py 其中包含了loger的日常用法
